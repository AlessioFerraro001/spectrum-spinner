package com.example.spectrumspinner;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

import static com.example.spectrumspinner.MainActivity.starthigh;

public class GameplayActivity extends AppCompatActivity {
    boolean alive = true;
    int score;
    static String endscore = "ENDSCORE";
    static String endhigh = "ENDHIGH";
    int ePos;
    int gamerank;
    int highscore;
    int color;
    int next;
    private Random r = new Random();
    float pPos;
    boolean rankup = false;
    private TextView scoreView;
    private TextView rankupView;
    private TextView highView;
    GameplayView mGameplayView;
    int width;
    int height;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gameplay);
        mGameplayView = (GameplayView) findViewById(R.id.drawings);
        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        width = size.x;
        height= size.y;
        mGameplayView.setDims(width, height);
        Intent intent=getIntent();
        highscore = intent.getIntExtra(starthigh, 0);
        scoreView = (TextView) findViewById(R.id.scoreText);
        rankupView = (TextView) findViewById(R.id.rankupText);
        highView = (TextView) findViewById(R.id.highText);
    }

    @Override
    protected void onStart()   {
        super.onStart();
        highView.setText("High Score: " + highscore);
        score = 0;
        ePos = 0;
        pPos = 0;
        gamerank = 2;
        color = r.nextInt(gamerank);
        next = r.nextInt(gamerank);
        Thread enemyThread = new Thread(enemy);
        enemyThread.start();
    }

    public void gameEnd(){
        alive = false;
        Intent intent=new Intent(this, GameoverActivity.class);
        intent.putExtra(endscore, score);
        intent.putExtra(endhigh, highscore);
        startActivity(intent);
        GameplayActivity.this.finish();
    }

    public Handler threadHandler = new Handler(){
        public void handleMessage (android.os.Message message){
            scoreView.setText("Score:" + Integer.toString(score));
            mGameplayView.setStuff(ePos, pPos, color, next, gamerank);
            mGameplayView.update();
        }

    };

    public Handler rankupHandler = new Handler(){
        public void handleMessage (android.os.Message message){
            if (rankup) {
                rankupView.setText("RANK UP");
            }
            else {
                rankupView.setText(" ");
            }
        }

    };

    private Runnable enemy = new Runnable() {
        public void run() {
            while (alive) {
                try {
                    ePos += 2 + (score / 5);
                    if (ePos >= 85) {
                        if (!playercheck()) {
                            gameEnd();
                        }
                        score++;
                        ePos = 0;
                        color = next;
                        next = r.nextInt(gamerank);
                        if (score % 10 == 0) {
                            if (gamerank < 6) {
                                gamerank++;
                                rankup = true;
                                rankupHandler.sendEmptyMessage(0);
                                Thread.sleep(2000);
                                rankup = false;
                                rankupHandler.sendEmptyMessage(0);
                            }
                        }
                    }
                    Thread.sleep(100);
                    threadHandler.sendEmptyMessage(0);
                }
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    };

    public boolean playercheck() {
        if (gamerank == 2) {
            if (color == 0) {
                if (pPos < width * (3.0 / 4.0) && pPos > width * (1.0 / 4.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 1) {
                if (pPos > width * (3.0 / 4.0) || pPos < width * (1.0 / 4.0)) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        if (gamerank == 3) {
            if (color == 0) {
                if (pPos < width * (3.0 / 4.0) && pPos > width * (1.0 / 4.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 1) {
                if (pPos > width * (3.0 / 4.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 2) {
                if (pPos < width * (1.0 / 4.0)) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        if (gamerank == 4) {
            if (color == 0) {
                if (pPos < width * (5.0 / 8.0) && pPos > width * (3.0 / 8.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 1) {
                if (pPos < width * (7.0 / 8.0) && pPos > width * (5.0 / 8.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 2) {
                if (pPos < width * (3.0 / 8.0) && pPos > width * (1.0 / 8.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 3) {
                if (pPos < width * (1.0/8.0) || pPos > width * (7.0/8.0)) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        if (gamerank == 5) {
            if (color == 0) {
                if (pPos < width * (6.0/10.0) && pPos > width * (4.0/10.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 1) {
                if (pPos < width * (8.0/10.0) && pPos > width * (6.0/10.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 2) {
                if (pPos < width * (4.0/10.0) && pPos > width * (2.0/10.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 3) {
                if (pPos > width * (8.0/10.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 4) {
                if (pPos < width * (2.0/10.0)) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        if (gamerank == 6) {
            if (color == 0) {
                if (pPos < width * (7.0/12.0) && pPos > width * (5.0/12.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 1) {
                if (pPos < width * (9.0/12.0) && pPos > width * (7.0/12.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 2) {
                if (pPos < width * (5.0/12.0) && pPos > width * (3.0/12.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 3) {
                if (pPos < width * (11.0/12.0) && pPos > width * (9.0/12.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 4) {
                if (pPos < width * (3.0/12/0) && pPos > width * (1.0/12.0)) {
                    return true;
                } else {
                    return false;
                }
            }
            else if (color == 5) {
                if (pPos < width * (1.0/12.0) || pPos > width * (11.0/12.0)) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        return true;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int touchAction = event.getActionMasked();
        if (touchAction == MotionEvent.ACTION_MOVE) {
                pPos = event.getX();
        }
        return true;
    }
}