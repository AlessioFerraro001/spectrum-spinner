package com.example.spectrumspinner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import static com.example.spectrumspinner.GameplayActivity.endhigh;
import static com.example.spectrumspinner.GameplayActivity.endscore;

public class GameoverActivity extends AppCompatActivity {
    int score;
    int highscore;
    protected DBHelper mDBHelper2;
    private TextView endScoreView;
    private TextView newHighView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gameover);
        Intent intent=getIntent();
        score = intent.getIntExtra(GameplayActivity.endscore, 0);
        highscore = intent.getIntExtra(GameplayActivity.endhigh, 0);
        endScoreView = (TextView) findViewById(R.id.endScoreText);
        endScoreView.setText("Score:" + Integer.toString(score));
        if (score > highscore) {
            mDBHelper2 = new DBHelper(this);
            mDBHelper2.updateHigh(score);
            newHighView = (TextView) findViewById(R.id.newHighView);
            newHighView.setText("NEW HIGH SCORE!");
        }
    }

    public void gameReturn(View view) {
        GameoverActivity.this.finish();
    }
}
