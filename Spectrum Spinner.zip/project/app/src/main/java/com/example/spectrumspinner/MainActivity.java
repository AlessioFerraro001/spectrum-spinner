package com.example.spectrumspinner;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int highscore;
    protected DBHelper mDBHelper;
    static String starthigh = "STARTHIGH";
    private TextView curHighView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mDBHelper = new DBHelper(this);
        curHighView = (TextView) findViewById(R.id.curHighText);
    }

    @Override
    protected void onResume() {
        super.onResume();
        highscore = mDBHelper.getHigh();
        curHighView.setText("High Score: " + highscore);
    }

    public void gameStart(View view){
        Intent intent=new Intent(this, GameplayActivity.class);
        intent.putExtra(starthigh, highscore);
        startActivity(intent);
    }

    public void resetHigh(View view) {
        mDBHelper.updateHigh(0);
        highscore = mDBHelper.getHigh();
        curHighView.setText("High Score: " + highscore);
    }
}
