package com.example.spectrumspinner;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v4.content.ContextCompat;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class GameplayView extends View {
    protected static int mTileSize;
    int enemyPos;
    float playerPos;
    int color;
    int next;
    int rank;
    static final float hundred = 100;
    float width;
    float height;
    float mid;
    float top;
    float bottom;

    Paint colors[];
    Paint black;
    Paint white;

    public GameplayView(Context context, AttributeSet attrs) {
        super(context, attrs);

        TypedArray a = context.obtainStyledAttributes(attrs, R.styleable.GameplayView);
        mTileSize = a.getDimensionPixelSize(R.styleable.GameplayView_tileSize, 12);
        a.recycle();
        colors = new Paint[6];
        colors[0] = new Paint();
        colors[0].setARGB(255, 255, 0, 0);
        colors[1] = new Paint();
        colors[1].setARGB(255, 0, 0, 255);
        colors[2] = new Paint();
        colors[2].setARGB(255, 0, 255, 0);
        colors[3] = new Paint();
        colors[3].setARGB(255, 255, 0, 255);
        colors[4] = new Paint();
        colors[4].setARGB(255, 255, 255, 0);
        colors[5] = new Paint();
        colors[5].setARGB(255, 0, 255, 255);
        black = new Paint();
        black.setARGB(255, 0, 0, 0);
        white = new Paint();
        white.setARGB(255, 255, 255, 255);

    }

    public void setStuff(int newEPos, float newPPos, int newColor, int newNext, int newRank) {
        enemyPos = newEPos;
        playerPos = newPPos;
        color = newColor;
        next = newNext;
        rank = newRank;
    }

    public void setDims(float setWidth, float setHeight) {
        width = setWidth;
        height = setHeight;
        mid = (height/100) * 85;
        top = mid - (height/20);
        bottom = mid + (height/20);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawRect(playerPos - (width/2), bottom + 2*(height/hundred), playerPos + (width/2), bottom + 3*(height/hundred), white);
        canvas.drawCircle(width / 2, height * (enemyPos / hundred), bottom-mid, colors[color]);
        canvas.drawCircle(width, 0, width / 4, colors[next]);
        if (rank == 2) {
            float side = width / (4);
            canvas.drawRect(playerPos - side, top, playerPos + side, bottom, colors[0]); //middle
            canvas.drawRect(playerPos - (side*3), top, playerPos - side, bottom, colors[1]); //left
            canvas.drawRect(playerPos - (side*5), top, playerPos - (side*3), bottom, colors[0]); //far-left
            canvas.drawRect(playerPos + side, top, playerPos + (side*3), bottom, colors[1]); //right
            canvas.drawRect(playerPos + (side*3), top, playerPos + (side*5), bottom, colors[0]); //far-right
        }
        else if (rank == 3) {
            float side = width / (4);
            canvas.drawRect(playerPos - side, top, playerPos + side, bottom, colors[0]); //middle
            canvas.drawRect(playerPos - (side*3), top, playerPos - side, bottom, colors[1]); //left
            canvas.drawRect(playerPos - (side*5), top, playerPos - (side*3), bottom, colors[2]); //far-left
            canvas.drawRect(playerPos + side, top, playerPos + (side*3), bottom, colors[2]); //right
            canvas.drawRect(playerPos + (side*3), top, playerPos + (side*5), bottom, colors[1]); //far-right
        }
        else if (rank == 4) {
            float side = width / (8);
            canvas.drawRect(playerPos - side, top, playerPos + side, bottom, colors[0]); //middle
            canvas.drawRect(playerPos - (side*3), top, playerPos - side, bottom, colors[1]); //left 1
            canvas.drawRect(playerPos - (side*5), top, playerPos - (side*3), bottom, colors[3]); //left 2
            canvas.drawRect(playerPos - (side*7), top, playerPos - (side*5), bottom, colors[2]); //left 3
            canvas.drawRect(playerPos - (side*9), top, playerPos - (side*7), bottom, colors[0]); //left 4
            canvas.drawRect(playerPos + side, top, playerPos + (side*3), bottom, colors[2]); //right 1
            canvas.drawRect(playerPos + (side*3), top, playerPos + (side*5), bottom, colors[3]); //right 2
            canvas.drawRect(playerPos + (side*5), top, playerPos + (side*7), bottom, colors[1]); //right 3
            canvas.drawRect(playerPos + (side*7), top, playerPos + (side*9), bottom, colors[0]); //right 4
        }
        else if (rank == 5) {
            float side = width / (10);
            canvas.drawRect(playerPos - side, top, playerPos + side, bottom, colors[0]); //middle
            canvas.drawRect(playerPos - (side*3), top, playerPos - side, bottom, colors[1]); //left 1
            canvas.drawRect(playerPos - (side*5), top, playerPos - (side*3), bottom, colors[3]); //left 2
            canvas.drawRect(playerPos - (side*7), top, playerPos - (side*5), bottom, colors[4]); //left 3
            canvas.drawRect(playerPos - (side*9), top, playerPos - (side*7), bottom, colors[2]); //left 4
            canvas.drawRect(playerPos - (side*11), top, playerPos - (side*9), bottom, colors[0]); //left 5
            canvas.drawRect(playerPos + side, top, playerPos + (side*3), bottom, colors[2]); //right 1
            canvas.drawRect(playerPos + (side*3), top, playerPos + (side*5), bottom, colors[4]); //right 2
            canvas.drawRect(playerPos + (side*5), top, playerPos + (side*7), bottom, colors[3]); //right 3
            canvas.drawRect(playerPos + (side*7), top, playerPos + (side*9), bottom, colors[1]); //right 4
            canvas.drawRect(playerPos + (side*9), top, playerPos + (side*11), bottom, colors[0]); //right 5
        }
        else if (rank == 6) {
            float side = width / (12);
            canvas.drawRect(playerPos - side, top, playerPos + side, bottom, colors[0]); //middle
            canvas.drawRect(playerPos - (side*3), top, playerPos - side, bottom, colors[1]); //left 1
            canvas.drawRect(playerPos - (side*5), top, playerPos - (side*3), bottom, colors[3]); //left 2
            canvas.drawRect(playerPos - (side*7), top, playerPos - (side*5), bottom, colors[5]); //left 3
            canvas.drawRect(playerPos - (side*9), top, playerPos - (side*7), bottom, colors[4]); //left 4
            canvas.drawRect(playerPos - (side*11), top, playerPos - (side*9), bottom, colors[2]); //left 5
            canvas.drawRect(playerPos - (side*13), top, playerPos - (side*11), bottom, colors[0]); //left 6
            canvas.drawRect(playerPos + side, top, playerPos + (side*3), bottom, colors[2]); //right 1
            canvas.drawRect(playerPos + (side*3), top, playerPos + (side*5), bottom, colors[4]); //right 2
            canvas.drawRect(playerPos + (side*5), top, playerPos + (side*7), bottom, colors[5]); //right 3
            canvas.drawRect(playerPos + (side*7), top, playerPos + (side*9), bottom, colors[3]); //right 4
            canvas.drawRect(playerPos + (side*9), top, playerPos + (side*11), bottom, colors[1]); //right 5
            canvas.drawRect(playerPos + (side*11), top, playerPos + (side*13), bottom, colors[0]); //right 5
        }
        canvas.drawCircle(playerPos, top - ((bottom - mid)/2), height/hundred, black);
    }

    public void update() {
        invalidate();
    }
}
